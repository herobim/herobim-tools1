<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Author extends CI_Controller {

	public function index()
	{
		$data['title'] = 'Author Website';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Pages/AuthorWeb');
		$this->load->view('Templates/footer');
	}
}