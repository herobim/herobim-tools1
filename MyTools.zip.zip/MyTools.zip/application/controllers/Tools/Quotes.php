<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quotes extends CI_Controller {

	public function index()
	{
		$data['title'] = 'Quotes Generator';
		$data['jenis'] = '<i class="fa fa-quote-left"></i> Quotes Generator <i class="fa fa-quote-right"></i>';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/Quotes/Quotes-Generator');
		$this->load->view('Templates/footer');
	}
}