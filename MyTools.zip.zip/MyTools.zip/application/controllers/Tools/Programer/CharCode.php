<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CharCode extends CI_Controller {

	public function index()
	{
		$data['title'] = 'CharCode Generator';
		$data['jenis'] = '<i class="fa fa-laptop"></i> Programer Tools';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/Programer/CharCode Generator');
		$this->load->view('Templates/footer');
	}
}