<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EnD extends CI_Controller {

	public function index()
	{
		$data['title'] = 'Encode - Decode';
		$data['jenis'] = '<i class="fa fa-laptop"></i> Programer Tools';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/Programer/Encode - Decode');
		$this->load->view('Templates/footer');
	}
}