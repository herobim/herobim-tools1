<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class IP extends CI_Controller {

	
	public function index()
	{
		$data['title'] = 'Ip Address Checker';
		$data['jenis'] = '<i class="fa fa-wifi"></i> Network Checker';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/Checker1/Ip-Checker');
		$this->load->view('Templates/footer');
	}
}