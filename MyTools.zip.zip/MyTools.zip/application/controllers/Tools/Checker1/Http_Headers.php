<?php
// 
class Http_Headers extends CI_Controller{
	public function index(){
		$data['title'] = 'Http Headers Status';
		$data['jenis'] = '<i class="fa fa-wifi"></i> Network Checker';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/Checker1/Http headers');
		$this->load->view('Templates/footer');
	}
}