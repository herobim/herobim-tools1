<?php
// https://api.hackertarget.com/dnslookup/?q=google.com
class Dns_LookUp extends CI_Controller{
	public function index(){
		$data['title'] = 'Dns LookUp';
		$data['jenis'] = '<i class="fa fa-wifi"></i> Network Checker';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/Checker1/Dns LookUp');
		$this->load->view('Templates/footer');
	}
}