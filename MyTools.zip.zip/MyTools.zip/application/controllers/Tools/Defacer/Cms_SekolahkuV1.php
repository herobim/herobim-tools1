<?php
   
class Cms_SekolahkuV1 extends CI_Controller{
	public function index(){
		$data['title'] = 'Auto Inject CMS Sekolahku';
		$data['jenis'] = '<i class="fa fa-bug"></i> Defacer Tools';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/Defacer/Cms SekolahkuV1');
		$this->load->view('Templates/footer');
	}
}