<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jso_generator extends CI_Controller {
	
	public function index()
	{
		$data['title'] = 'Script Jso Generator';
		$data['jenis'] = '<i class="fa fa-bug"></i> Defacer Tools';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/Defacer/Jso-Generator');
		$this->load->view('Templates/footer');
	}
	
}