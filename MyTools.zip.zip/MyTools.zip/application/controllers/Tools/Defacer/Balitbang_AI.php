<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Balitbang_AI extends CI_Controller {

	public function index()
	{
		$data['title'] = 'Balitbang Auto Inject';
		$data['jenis'] = '<i class="fa fa-bug"></i> Defacer Tools';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/Defacer/Balitbang Auto Inject');
		$this->load->view('Templates/footer');
	}
}