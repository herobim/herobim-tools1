<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ZoneH extends CI_Controller {

	public function index()
	{
		$data['title'] = 'ZoneH Mass Notify';
		$data['jenis'] = 'ZoneH Mass Notify';
		$this->load->view('Templates/header',$data);
		$this->load->view('Templates/sidebar');
		$this->load->view('Tools/ZoneH/Zone-H Mass Notify');
		$this->load->view('Templates/footer');
	}
}