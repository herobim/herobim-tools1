<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	 </div>
	 
<div class="tile">
	<form method="post">
		<input type="email" name="email" class="form-control mb-3" required="required" placeholder="Email...">
		<input type="number" name="pesan" placeholder="Jumlah Pesan..." required="required" class="form-control mb-3">
		<button type="submit" name="send" class="btn btn-danger btn-block">Send Email</button>
	</form>
</div>
<?php
if(isset($_POST['send'])){
	$email   = htmlspecialchars(addslashes($_POST['email']), ENT_QUOTES);
	$subject = $_SERVER['HTTP_HOST'];
	$pesan   = 'Spamm Email Mankk\n'.$subject;
	$header  = 'Spamm';
	$jumlah  = $_POST['pesan'];
	if($email == 'andrewahyuu11@gmail.com'){
		echo 'Matamu Cokk';
	}else{
	for($i = 0; $i <= $jumlah; $i++){
			if(mail($email,$subject,$pesan,$header)){
			$berhasil = true;
		}else{
			$gagal = true;
		}
	}
}
if(isset($berhasil)){
	echo '
			<div class="tile text-center"><h2>Hasil</h2><hr>
				<p>Berhasil Mengirim <b>'.$jumlah.'</b> pesan ke <b>'.$email.'</b></p>
			</div>';
}elseif(isset($gagal)){
	echo '
			<div class="tile text-center"><h2>Hasil</h2><hr>
				<p>Gagal Mengirim <b>'.$jumlah.'</b> pesan ke <b>'.$email.'</b></p>
			</div>';
	}
}
?>
</main>