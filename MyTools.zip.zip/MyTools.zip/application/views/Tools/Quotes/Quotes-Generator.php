<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></i></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	 </div>
	 
	 <form method="post">
		<div class="row">
		 	<div class="col-md-6">
		 		<div class="tile">
		 			<input type="text" name="nama" class="form-control" required="required" placeholder="Nama Kamu">
		 		</div>
		 	</div>
		 	
		 	<div class="col-md-6">
		 		<div class="tile">
		 			<input type="url" name="link" class="form-control" required="required" placeholder="Link Gambar">
		 		</div>
		 	</div>
		 </div>
		 
		 <div class="tile">
		 	<input type="text" name="quote1" class="form-control mb-3" placeholder="Kata 1" autocomplete="off">
		 	<input type="text" name="quote2" class="form-control mb-3" placeholder="Kata 2" autocomplete="off">
		 	<input type="text" name="quote3" class="form-control" placeholder="Kata 3" autocomplete="off">
		 		<small class="form-text text-muted">Ga diisi semua? No Problem</small><hr>
		 	<div class="row">
		 		<div class="col">
		 			<button type="submit" name="buat" class="btn btn-primary btn-block">Generate</button>
		 		</div>
		 		
		 		<div class="col">
		 			<button type="reset" class="btn btn-danger btn-block">Reset</button>
		 		</div>
		 	</div>
		 </div>
	 </form>
	 
<?php
	if(isset($_POST["buat"])){
		$nama  = htmlspecialchars($_POST["nama"]);
		$quote = htmlspecialchars($_POST["quote1"]);
		$quote2 = htmlspecialchars($_POST["quote2"]);
		$quote3 = htmlspecialchars($_POST["quote3"]);
		$link  = $_POST["link"];
		
		
$hasil = '<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.75, shrink-to-fit=no">
    <meta name="description" content="I Am Sadd Boy">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Mali:400i,700i" rel="stylesheet" type="text/css">
    <link rel="icon" href="https://images4.alphacoders.com/220/220444.jpg" type="image/jpg">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Rock Salt|Righteous" rel="stylesheet">
    <title></title>
    <style>
    	html,body,.container{
    		background: url('.$link.') no-repeat center center/cover;
    		background-color: rgba(0,0,0,0.4);
    		position: fixed;
    		margin: auto;
    		height: 100%;
    		top: 0; bottom: 0; left: 0; right:0;
    	}
    	.page{
    		position: absolute;
    		margin: auto;
    		height: 50%;
    		top: 0; bottom: 0; left: 0; right:0;
    	}
    	.mek{
    		background-color:rgba(0,0,0,0.4);
    	}
    	h1{
    		transform:rotate(-12deg); 
    		-moz-transform:rotate(-12deg); 
    		-webkit-transform:rotate(-12deg); 
    		-o-transform:rotate(-12deg);
    		font-family: "Mali";
    		font-size: 2em;
    		font-weight: bold;
    		margin-bottom: 15%;
    	}
    	h5{
    		font-family: "Righteous";
    	}
    	.logo{
    		text-decoration: none;
    		color: white;
    		font-size: 22px;
    		margin: 10px;
    	}
    	.logo:hover{
    		text-decoration: none;
    		color: white;
    		cursor: pointer;
    	}
    	.hastag{
    		text-decoration: none;
    		color: white;
    	}
    	p{
    		color: white;
    		padding-top: 10px;
    		font-size: 14px;
    	}
    </style>
  </head>
  <body>
  	
    <div class="container">
    	<div class="page">
    		<h1 class="text-center text-white">- '.$nama.' -</h1>
    		
    		<div class="mek">
    		<h5 class="text-center text-white mb-3"><hr><i>'.$quote.'<br>'.$quote2.'<br>'.$quote3.'</i><hr></h5>
    		
    	</div>
    	<footer><center>
    		<a class="logo" href="">
    			<i class="fab fa-whatsapp"></i>
    		</a>
    		<a class="logo" href="">
    			<i class="fab fa-hackerrank"></i>
    		</a>
    		<a class="logo" href="">
    			<i class="fab fa-github"></i>
    		</a>
    		<a class="logo" href="">
    			<i class="fas fa-globe"></i>
    		</a>
    		<a class="logo" href="">
    			<i class="fab fa-blogger"></i>
    		</a><br>
    			<p class="mt-3">www.'.$_SERVER["SERVER_NAME"].'.com</p>
    		</center></footer>
    </div>

  </body>
</html>';
$buat  = fopen("hasil.html","w");
						 fwrite($buat,$hasil);
						 fclose($buat);
?>

	<div class="tile">
		<center>
			<iframe src="<?= base_url('hasil.html') ?>" height="250px" class="form-control" id="screenshot"></iframe><hr>
			<a href="<?= base_url('hasil.html') ?>" class="btn btn-success btn-block" id="a-make">Lihat</a>
			
		</center>
	</div>
	
<?php } ?>
	 <script>
    function makeScreenshot()
    {
        html2canvas(document.getElementById("screenshot"), {scale: 2}).then(canvas =>
        {
            canvas.id = "canvasID";
            var main = document.getElementById("main");
            while (main.firstChild) { main.removeChild(main.firstChild); }
            main.appendChild(canvas);
        });
    }

    document.getElementById("a-make").addEventListener('click', function()
    {
        document.getElementById("a-make").style.display = "none";
        makeScreenshot();
        document.getElementById("a-download").style.display = "inline";
    }, false);

    document.getElementById("a-download").addEventListener('click', function()
    {
        this.href = document.getElementById("canvasID").toDataURL();
        this.download = "canvas-image.png";
    }, false);
</script>
</main>