<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
</div>

<form method="post">
	<div class="row">
		<div class="col-md-6">
			<div class="tile">
				<input type="text" name="target" class="form-control" required="required" placeholder="Domain/Ip Address">
			</div>
		</div>
		<div class="col-md-6">
			<div class="tile">
				<input type="number" name="port" class="form-control" required="required" placeholder="Port">
			</div>
		</div>
	</div>
	<div class="tile">
		<button type="submit" class="btn btn-danger btn-block" name="check">Check Status</button>
	</div>
</form>

<?php
if(isset($_POST["check"])){
	$target = htmlspecialchars(addslashes($_POST["target"]));
	$ports  = htmlspecialchars($_POST["port"]);
	
	$query  = [
	"remoteAddress" => $target,
	"portNumber" => $ports];
	$data   = http_build_query($query); // ubah params
	
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://ports.yougetsignal.com/check-port.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$hc = curl_exec($ch);
if(preg_match("/open/",$hc)){
	echo '<div class="tile text-center">
		<h4>Result</h4>
		<p>Port <a href="#">'.$ports.'</a> terbuka pada <a href="'.$target.'">'.$target.'</a></p></div>';
}else{
	echo '<div class="tile text-center">
		<h4>Result</h4>
		<p>Port <a href="#">'.$ports.'</a> tertutup pada '.$target.'</p></div>';
}
}else{
	echo '<div class="tile text-center">
		<h4>About Tools</h4><hr>
		<p>Alat ini berguna untuk mencari tahu apakah penerusan port Anda sudah diatur dengan benar atau jika aplikasi server Anda diblokir oleh firewall. Alat ini juga dapat digunakan sebagai pemindai port untuk memindai jaringan Anda untuk port yang umumnya diteruskan.</p></div>';
}
?>

</main>