<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?> <i class="fa fa-eye"></i></li>
        </ul>
      </div>
	</div>
<form method="post">
	<div class="tile">
		<div class="row">
			<div class="col">
				<input type="tel" name="web" class="form-control" placeholder="127.0.0.1" required="required">
			</div>
			<div class="col-md-2">
				<button type="submit" name="cari" class="btn btn-danger btn-block">Search</button>
			</div>
		</div>
	</div>
</form>

<?php
if(isset($_POST["cari"])){
	$Ip = htmlspecialchars(addslashes($_POST["web"]));
	$array = ["q" => $Ip];
	$data = http_build_query($array);
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.hackertarget.com/nmap/?$data");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
	$hc = curl_exec($ch);
	echo '<div class="tile"><h4>Result '.$Ip.'</h4><hr>
		<div class="table-responsive-lg">
			<pre>'.$hc.'</pre>
			</div>
	</div>';
}else{
	echo '<div class="tile text-center"><h4>About Tools</h4><hr><p><b>Nmap</b>(Network Mapper) adalah sebuah aplikasi atau tools yang berfungsi untuk melakukan port scanning.<br>Tools ini digunakan untuk meng-audit jaringan yang ada. Dengan menggunakan tools ini, kita dapat melihat host yang aktif, port yang terbuka, Sistem Operasi yang digunakan, dan feature-feature scanning lainnya.</p></div>';
}
?>
</main>