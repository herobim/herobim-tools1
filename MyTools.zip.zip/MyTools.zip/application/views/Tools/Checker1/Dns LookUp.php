	<main class="app-content">
		<div class="app-title">
			<div>
	          <h1><?= $jenis; ?></h1>
	        </div>
	        <ul class="app-breadcrumb breadcrumb">
	          <a href="<?= base_url() ?>">
	          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
	          <li class="breadcrumb-item"><?= $title; ?></li>
	        </ul>
	      </div>
		</div>
	</div>
<div class="tile">
	<form method="post">
		<div class="row">
			<div class="col">
				<input type="text" name="web" required="required" placeholder="Nama domain" class="form-control">
			</div>
			<div class="col">
				<button type="submit" name="cek" class="btn btn-primary btn-block">Cek</button>
			</div>
		</div>
	</form>
</div>
<?php
if(isset($_POST['cek'])){
	$url = htmlspecialchars(addslashes($_POST['web']));
	$data = file_get_contents('https://api.hackertarget.com/dnslookup/?q='.$url);
	echo '<div class="tile">
		<pre>'.$data.'</pre>
		</div>';
}
?>
</main>