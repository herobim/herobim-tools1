<main class="app-content">
		<div class="app-title">
			<div>
	          <h1><?= $jenis; ?></h1>
	        </div>
	        <ul class="app-breadcrumb breadcrumb">
	          <a href="<?= base_url() ?>">
	          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
	          <li class="breadcrumb-item"><?= $title; ?></li>
	        </ul>
	      </div>
		</div>
	</div>
	<div class="tile">
		<form method="post">
					<input type="tel" name="ip" class="form-control mb-3" required="required" placeholder="Ip Address">
					<button type="submit" name="cek" class="btn btn-success btn-block">Cek</button>
		</form>
	</div>
<?php
if(isset($_POST['cek'])){
	$ip = htmlspecialchars(addslashes($_POST['ip']));
	$data = file_get_contents('https://api.hackertarget.com/reverseiplookup/?q='.$ip);
	echo '<div class="tile">
		<div class="table-responsive-lg">
			<pre>'.$data.'</pre>
			</div>
		</div>';
}
?>
</main>