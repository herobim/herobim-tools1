<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
</div>
	
	<div class="row">
		<div class="col-md-6">
			<div class="tile">
				
<?php
if(isset($_POST["check"])){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.ipify.org?format=json");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	$hc = curl_exec($ch);
	$js = json_decode($hc);
	foreach($js as $key){
		echo '<h3 class="text-center">'.$key.'</h3>';
	}
}else{
	echo '<h3 class="text-center">Lihat Ipku</h3>';
}
?>
				
			</div>
		</div>
		<div class="col-md-6">
			<div class="tile">
				<form method="post">
					<button type="submit" name="check" class="btn btn-info btn-block">Check Ip</button>
				</form>
			</div>
		</div>
	</div>
	
	
</main>