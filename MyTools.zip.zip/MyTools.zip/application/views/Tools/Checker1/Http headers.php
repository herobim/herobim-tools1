<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
</div>

<form method="post">
	<div class="row">
		<div class="col-md-6">
			<div class="tile">
				<input type="url" name="target" class="form-control" placeholder="Website">
			</div>
		</div>
		<div class="col-md-6">
			<div class="tile">
			<button type="submit" name="cari" class="btn btn-info btn-block">Check</button>
		</div>
	</div>
</div>
</form>

<?php
if(isset($_POST["cari"])){
	$datas = htmlspecialchars(addslashes($_POST['target']));
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.hackertarget.com/httpheaders/?q=$datas");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$hc = curl_exec($ch);
	echo '<div class="tile"><h4>Result '.$datas.'</h4><hr>
		<div class="table-responsive-lg">
			<pre>'.$hc.'</pre>
			</div>
	</div>';
}
?>
</main>