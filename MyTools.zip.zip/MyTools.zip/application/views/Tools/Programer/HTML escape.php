<?php
error_reporting(0);
if(isset($_POST["kontol"])){
	if(empty($input = $_POST["input"])){
		echo '<script>swal("Kesalahan", "Input kode tidak boleh kosong", "error")</script>';
	}
function encode($input) 
{ 
    $temp = ''; 
    $length = strlen($input); 
    for($i = 0; $i < $length; $i++) 
        $temp .= '%' . bin2hex($input[$i]); 
    return $temp; 
} 
$str = encode($input); 
$enc = "<!-- Escape By ./R4ND5@22XploiterCrew -->
<script language='javascript'>
document.write(escape('".$str."'));
</script>";
}

?>

<script>
		function copy() {
			document.getElementById("output").select();
			document.execCommand("copy");
			alert("Sukses");
		}
	
</script>

<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
</div>

<form method="post">
<div class="row">
	<div class="col-md-6">
		<div class="tile">
			<textarea class="form-control" rows="8" name="input" id="input" placeholder="Kode Kamu"></textarea>
		</div>
	</div>
	<div class="col-md-6">
		<div class="tile">
			<textarea class="form-control bg-transparent" rows="8" name="output" id="output" placeholder="Hasil Escape" readonly="readonly"><?= str_replace("escape","unescape",$enc); ?></textarea>
		</div>
	</div>
</div>
<div class="tile">
	<div class="row">
		<div class="col">
			<button class="btn btn-danger btn-block" type="submit" name="kontol">Escape Code</button>
		</div>
		<div class="col">
			<button type="button" class="btn btn-danger btn-block" onclick="copy()">Copy Kode</button>
		</div>
	</div>
</div>
</form>

</main>