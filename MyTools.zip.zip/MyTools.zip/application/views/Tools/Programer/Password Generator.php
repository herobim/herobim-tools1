<script>
	function md2() {
			document.getElementById("md2").select();
			document.execCommand("copy");
			alert("Berhasil di copy");
		}
	function md4() {
			document.getElementById("md4").select();
			document.execCommand("copy");
			alert("Berhasil di copy");
		}
	function md5() {
			document.getElementById("md5").select();
			document.execCommand("copy");
			alert("Berhasil di copy");
		}
	function sha1() {
			document.getElementById("sha1").select();
			document.execCommand("copy");
			alert("Berhasil di copy");
		}
	function sha224() {
			document.getElementById("sha224").select();
			document.execCommand("copy");
			alert("Berhasil di copy");
		}
	function sha512() {
			document.getElementById("sha512").select();
			document.execCommand("copy");
			alert("Berhasil di copy");
		}
	function ripemd256() {
			document.getElementById("ripemd256").select();
			document.execCommand("copy");
			alert("Berhasil di copy");
		}
	function Bc() {
			document.getElementById("Bc").select();
			document.execCommand("copy");
			alert("Berhasil di copy");
		}
	function Bb() {
			document.getElementById("Bb").select();
			document.execCommand("copy");
			alert("Berhasil di copy");
		}
</script>
<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
	
<div class="tile">
	<form method="post">
		<input type="text" name="pass" class="form-control mb-3" placeholder="Text generate">
		<button type="submit" name="hash" class="btn btn-info btn-block">Hash Password</button>
	</form>
</div>

<?php
if(isset($_POST["hash"])){
	$pass = htmlspecialchars(addslashes($_POST["pass"]));
if(!empty($pass)){
echo '<div class="row">
	<div class="col-md-6">
		<div class="tile">
			<li class="mb-2">Md2</li>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("md2",$pass).'" onclick="md2()" id="md2">
		</div>
	</div>
	
	<div class="col-md-6">
		<div class="tile">
			<li class="mb-2">Md4</li>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("md4",$pass).'" onclick="md4()" id="md4">
		</div>
	</div>
</div>


<div class="row">
	<div class="col-md-6">
		<div class="tile">
			<li class="mb-2">Md5</li>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.md5($pass).'" onclick="md5()" id="md5">
		</div>
	</div>
	
	<div class="col-md-6">
		<div class="tile">
			<li class="mb-2">Sha1</li>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.sha1($pass).'" onclick="sha1()" id="sha1">
		</div>
	</div>
</div>


<div class="row">
	<div class="col-md-6">
		<div class="tile">
			<li class="mb-2">Sha224</li>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("sha224",$pass).'" onclick="sha224()" id="sha224">
		</div>
	</div>
	
	<div class="col-md-6">
		<div class="tile">
			<li class="mb-2">Sha512</li>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("sha512",$pass).'" onclick="sha512()" id="sha512">
		</div>
	</div>
</div>


<div class="row">
	<div class="col-md-6">
		<div class="tile">
			<li class="mb-2">Ripemd256</li>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("ripemd256",$pass).'" onclick="ripemd256()" id="ripemd256">
		</div>
	</div>
	
	<div class="col-md-6">
		<div class="tile">
			<li class="mb-2">Bcrypt Default</li>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.password_hash($pass,PASSWORD_DEFAULT).'" onclick="Bc()" id="Bc">
		</div>
	</div>
</div>

<div class="tile">
	<li class="mb-2">Bcrypt Blowfish</li>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.password_hash($pass,PASSWORD_BCRYPT).'" onclick="Bb()" id="Bb">
</div>';
	}
}
?>
</main>