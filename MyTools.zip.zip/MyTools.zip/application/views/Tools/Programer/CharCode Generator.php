<script>
		function salin() {
			document.getElementById("output").select();
			document.execCommand("copy");
			swal("Berhasil", "Kode Berhasil Disalin", "success")
		}
	function runCharCodeAt() {
			input = document.charCodeAt.input.value;
			output = "";
			for(i=0; i < input.length; ++i) {
				if (output != "") output += "";
				output += input.charCodeAt(i);
			}
			document.charCodeAt.output.value = output;
		}
	</script>

<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
	
			<div class="tile">
				<div class="tile-body">
					<form name="charCodeAt" method="post">
		<textarea name="input" class="form-control" placeholder="Place Text In Here!" rows="8"></textarea>
				</div>
			</div>
			
		<div class="tile">
			<div class="row">
				<div class="col">
					<button type="button" onclick="runCharCodeAt()" class="btn btn-primary btn-block"><i class='fa fa-plus'></i></button>
		</div>
	<div class="col">
			<button type="button" onclick="salin()" class="btn btn-success btn-block"><i class='fa fa-clone'></i></button>
				</div>
			</div>
		</div>
		
		<div class="tile">
			<textarea id="output" class="form-control bg-transparent" rows="8" placeholder="Result Char Code" readonly="readonly"></textarea>
		</div>
</main>