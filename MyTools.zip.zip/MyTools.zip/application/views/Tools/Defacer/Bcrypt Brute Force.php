<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
		</div>
		
				<div class="tile">
					<form method="post">
						<input type="text" name="input" class="form-control mb-3" required="required" placeholder="Password Bcrypt">
						<input type="text" name="inputz" class="form-control mb-3" required="required" placeholder="Text Brute"><hr>
						<button type="submit" name="crack" class="btn btn-primary btn-block">Check</button>
			</form>
		</div>
	<?php
if(isset($_POST["crack"])){
	$input  = htmlentities($_POST["input"]);
	$inputz = htmlentities($_POST["inputz"]);
		if(password_verify($inputz,$input)){
			echo '<div class="tile">
			<h3 class="tile-title"><i class="fa fa-exclamation-triangle"></i> Found</h3>
            <ul>
              <li>Password : '.$inputz.'</li>
            </ul>
		</div>';
		}else{
			echo '<div class="tile">
			<h3 class="tile-title"><i class="fa fa-exclamation-triangle"></i> Not Found</h3>
			<ul>
              <li>Password : ?</li>
            </ul>
		</div>';
		}
}else{
	echo '<div class="tile">
            <h3 class="tile-title"><i class="fa fa-exclamation-triangle"></i> Cara menggunakan</h3>
            <ul>
              <li>Masukkan password hash bertype bcrypt di inputan yang ada di atas</li>
              <li>Lalu masukkan text password bruteforce kalian ke inputan ke 2</li>
              <li>Klik submit</li>
            </ul>
        </div>';
}
?>
          
</main>