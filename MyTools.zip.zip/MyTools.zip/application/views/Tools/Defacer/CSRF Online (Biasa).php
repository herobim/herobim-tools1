<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
	
<form method="post">
			<div class="tile">
			<input type="url" name="url" class="form-control" placeholder="Url Target" required="required">
			</div>
	
	<div class="tile">
		<div class="row">
			<div class="col-md-6">
				<input type="text" name="post" class="form-control" placeholder="Filedata / files[] / qqfile / userfile / dll" required="required">
			</div>
			<div class="col-md-6">
				<input type="submit" name="kunci" class="btn btn-danger btn-block" value="Lock Target">
			</div>
		</div>
	</div>
</form>
	
<?php
error_reporting(0);
$url  = $_POST["url"];
$post = $_POST["post"];
if(isset($_POST["kunci"])){
	echo '<div class="tile">
  		<form method="post" class="vas-validated" enctype="multipart/form-data" action="'.$url.'">
  		<div class="row">
  			<div class="col">
  			<input id="uploadFile" placeholder="Nama File" disabled="disabled" class="form-control" id="look">
  				</div>
  				<div class="col">
  		<div class="input-group">
  <div class="custom-file">
    <input type="file" class="custom-file-input bg-transparent" id="uploadBtn" name="$post">
    <label class="custom-file-label bg-transparent" for="uploadFile"></label>
  </div>
 </div>
</div>
<div class="container">
    <button class="btn btn-outline-secondary btn-block mt-2" type="submit" name="upload">Upload</button>
  		</form>
<script type="text/javascript">
	document.getElementById("uploadBtn").onchange = function(){
		document.getElementById("uploadFile").value = this.value;
};
</script></div></div>';
}
?>
	</div>
	
</main>