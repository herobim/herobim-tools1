<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
	
	<div class="tile">
		<form method="post">
			<input type="text" name="input" class="form-control mb-3" required="required" autocomplete="off" placeholder="Password" value="">
			<button type="submit" name="crack" class="btn btn-info btn-block">Crack</button>
		</form>
	</div>
	
<?php
error_reporting(0);
if(isset($_POST["crack"])){
	$pass = htmlspecialchars(addslashes($_POST["input"]));
		function unhex($str = '', $code = ''){
		$all = explode("g",$str);
		
		$alls = hexdec($all[0]) - $code;
		$test = $all[1];
		if($alls == strlen($test)/2){
			for($i = 0; $i <= $alls-1; $i++){
				$result .= chr(hexdec(substr($test,$i*2,2)) - $code);
			}
			$result = strrev($result);
		}
		return $result;
	}
	
	for($is = 0; $is <= 100; $is++){
		$post = unhex($pass,$is);
 		if($post){
 			$yess = $post;
 		}
	}
	if($yess){
		echo '<script>
swal("Password Ditemukan", "", "success")
</script>
<div class="tile">
    <li><i class="fa fa-key"></i> Password : '.$yess.'</li>
</div>';
	}else{
		echo '<script>
swal("Password Tidak Ditemukan", "", "error")
</script>
<div class="tile">
	 <li><i class="fa fa-key"></i> Password : ?</li>
             
</div>';
	}
}
?>
</main>