<main class="app-content">
	<div class="app-title">
		<div>
          <h1><?= $jenis; ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <a href="<?= base_url() ?>">
          	<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></a></li>
          <li class="breadcrumb-item"><?= $title; ?></li>
        </ul>
      </div>
	</div>
<?php

if(isset($_POST["mirror"])){
	echo "<div class='tile'>
		<div class='table-responsive-lg'>
			<h4 class='text-center'>Notify Result</h4><hr>";
	$nick   = htmlspecialchars($_POST["nick"], ENT_QUOTES);
	$web    = htmlspecialchars($_POST['domain'], ENT_QUOTES);
	$domain = explode("\n", $web);
	if(!empty($domain && $web && $nick)){
	echo "<small>Defacer OnHold : <a href='http://www.zone-h.org/archive/notifier=$nick/published=0' target='_blank' data-toggle='tooltip' data-placement='left' title='http://www.zone-h.org/archive/notifier=$nick/published=0'>Klik Disini</a></small><br>";
	echo "<small>Defacer Archive : <a href='http://www.zone-h.org/archive/notifier=$nick' target='_blank' data-toggle='tooltip' data-placement='left' title='http://www.zone-h.org/archive/notifier=$nick'>Klik Disini</a></small><hr>";
	function ZoneH($domain,$nick){
		$arr = [
		"defacer"  => $nick,
		"domain1"  => $domain,
		"hackmode" => "1",
		"reason"   => "1",
		"submit"   => "Send"
		];
		$data = http_build_query($arr);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "http://www.zone-h.com/notify/single");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		return curl_exec($ch);
		curl_close($ch);
	}
	foreach($domain as $key){
		$mirror = ZoneH($key,$nick);
		if(preg_match("/color=\"red\">OK<\/font><\/li>/i", $mirror)){
			echo "<small>$key => <font color='lime'>OK</font></small><br>";
		}else{
			echo "<small>$key => <font color='red'>ERROR</font></small><br>";
		}
	}
}
	echo "</div></div>";
}else{

?>
	
	<form method="post"><!-- -->
		<div class="tile">
			<input type="text" name="nick" class="form-control mb-3" placeholder="Nick..." autofocus="autofocus">
			<select class="custom-select">
				<option selected="selected">Option</option>
				<option value='Not Available'>Not Available</option>
	    	<option value='SQL Injection'>SQL Injection</option>
	    	<option value='URL Poisoning'>URL Poisoning</option>
	    	<option value='File Inclusion'>File Inclusion</option>
	    	<option value='DNS Hijacking'>DNS Hijacking</option>
	    	<option value='DNS Poisoning'>DNS Poisoning</option>
	    	<option value='Admin poor Password'>Admin poor Password</option>
			</select>
		</div>
		<div class="tile">
			<textarea class="form-control" rows="6" placeholder="Domain..." name="domain"></textarea>
			<button type="submit" name="mirror" class="btn btn-danger btn-block mt-3">Execute</button>
		</div>
	</form>
	
	<?php } ?>
</main>