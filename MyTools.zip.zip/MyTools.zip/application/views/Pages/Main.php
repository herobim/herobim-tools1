<script>
	function Info(){
		swal("Informasi", "Anda telah berada di halaman utama", "info");
	}
</script>
<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-code"></i>My Online Tools</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#" onclick="Info()">Home</a></li>
        </ul>
      </div>
      
      <div class="tile text-center p-2">
      	<h5>Informasi Pengunjung</h5>
      	<small><?= date("l, d-m-Y") ?></small>
      </div>
      
      <div class="tile">
      	<div class="table-responsive-lg">
      		<table class="table table-bordered">
      			<tr>
      				<td align="left">Ip Address</td>
      				<td align="right"><?= $ip_address; ?></td>
      			</tr>
      			<tr>
      				<td align="left">Platform</td>
      				<td align="right"><?= $os; ?></td>
      			</tr>
      			<tr>
      				<td align="left">Browser</td>
      				<td align="right"><?= $browser; ?></td>
      			</tr>
      			<tr>
      				<td align="left">Versi Browser</td>
      				<td align="right"><?= $browser_version; ?></td>
      			</tr>
      		</table>
      	</div>
      </div>
      
    </main>