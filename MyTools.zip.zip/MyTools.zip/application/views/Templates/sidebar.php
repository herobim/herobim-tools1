<body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="#" data-toggle="tooltip" data-placement="bottom" title="<?= base_url() ?>">My Tools</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-drivers-license fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="<?= base_url('Author') ?>" onclick=""><i class="fa fa-user fa-lg"></i> Author</a></li>
            
          </ul>
        </li>
      </ul>
      
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <ul class="app-menu">
        <li><a class="app-menu__item active" href="<?= base_url() ?>" onclick=""><i class="app-menu__icon fa fa-home"></i><span class="app-menu__label">Welcome To My Tools</span></a></li>
        
        
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview">
        	<i class="app-menu__icon fa fa-bug"></i><span class="app-menu__label">Defacer Tools</span>
        	<i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="<?= base_url('Tools/Defacer/Jso_generator') ?>" onclick=""><i class="icon fa fa-genderless"></i> Jso Generator</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Defacer/Bcrypt_BF') ?>" onclick="" rel="noopener"><i class="icon fa fa-genderless"></i> Bcrypt Brute Force</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Defacer/Lokomedia_AI') ?>" onclick="" rel="noopener"><i class="icon fa fa-genderless"></i> Lokomedia Auto Exploit</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Defacer/SchoolHost_Xploit') ?>" onclick="" rel="noopener"><i class="icon fa fa-genderless"></i> SchoolHost Exploit</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Defacer/CSRF') ?>" onclick="" rel="noopener"><i class="icon fa fa-genderless"></i> CSRF Online</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Defacer/Sqli_Query') ?>" onclick="" rel="noopener"><i class="icon fa fa-genderless"></i> Query Sql Injection</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Defacer/Cms_SekolahkuV1') ?>" onclick=""><i class="icon fa fa-genderless"></i> Auto Inject Sekolahku V1</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Defacer/Balitbang_AI') ?>" onclick=""><i class="icon fa fa-genderless"></i> Auto sql balitbang</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Defacer/Balitbang_CP') ?>" onclick=""><i class="icon fa fa-genderless"></i> Crack Password Balitbang</a></li>
          </ul>
        </li>
        
        
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-keyboard-o"></i><span class="app-menu__label">Programer Tools</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="<?= base_url('Tools/Programer/EnD') ?>" onclick=""><i class="icon fa fa-genderless"></i> Encode - Decode</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Programer/HTML_EN') ?>" onclick=""><i class="icon fa fa-genderless"></i> HTML Escape</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Programer/CharCode') ?>" onclick=""><i class="icon fa fa-genderless"></i> CharCode Generator</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Programer/Password_Create') ?>" onclick=""><i class="icon fa fa-genderless"></i> Password Generator</a></li>
          </ul>
        </li>
        
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-wifi"></i><span class="app-menu__label">Network Checker</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="<?= base_url('Tools/Checker1/IP') ?>" onclick=""><i class="icon fa fa-genderless"></i> Ip Checker</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Checker1/Whois_Lookup') ?>" onclick=""><i class="icon fa fa-genderless"></i> Whois LookUp</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Checker1/Reverse_Ip') ?>" onclick=""><i class="icon fa fa-genderless"></i> Reverse Ip LookUp</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Checker1/PortF') ?>" onclick=""><i class="icon fa fa-genderless"></i> Port Forwading</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Checker1/Http_Headers') ?>" onclick=""><i class="icon fa fa-genderless"></i> HTTP Headers</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Checker1/Dns_Shared') ?>" onclick=""><i class="icon fa fa-genderless"></i> Find Shared Dns</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Checker1/Dns_LookUp') ?>" onclick=""><i class="icon fa fa-genderless"></i> Dns LookUp</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Checker1/Nmap') ?>" onclick=""><i class="icon fa fa-genderless"></i> Nmap</a></li>
          </ul>
        </li>
        
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-phone"></i><span class="app-menu__label">Spammer</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="<?= base_url('Tools/Spammer/Tokped') ?>" onclick=""><i class="icon fa fa-genderless"></i> Spam Call/SMS Tokopedia</a></li>
            <li><a class="treeview-item" href="<?= base_url('Tools/Spammer/Email') ?>" onclick=""><i class="icon fa fa-genderless"></i> Email Spammer</a></li>
          </ul>
        </li>
        
        <li><a class="app-menu__item" href="<?= base_url('Tools/ZoneH') ?>" onclick="">
        	<i class="app-menu__icon fab fa-hackerrank"></i><span class="app-menu__label">Zone-H Mass Notify</span></a></li>
        
        <li><a class="app-menu__item" href="<?= base_url('Tools/Quotes') ?>" onclick="">
        	<i class="app-menu__icon fa fa-quote-left"></i><span class="app-menu__label">Simple Quote Generator</span></a></li>
    </aside>