<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Jadikan bacotanmu sebagai bukti masa depanmu.">
    	
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Coding Zone">
    <meta property="og:url" content="Online Tools">
    <script type="text/javascript" src="<?= base_url() ?>Data-Template/js/sweetalert.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Righteous|Aldrich" rel="stylesheet">
  
    <title><?= $title; ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQcy5TDe1Ja2STGhX4sT6L0E19joeZjvVMPwAEfeNSaSpggmDh0" type="image/jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>Data-Template/css/main.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>Data-Template/font-awesome/css/font-awesome.min.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  </head>