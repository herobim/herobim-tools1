<footer class="sticky-footer bg-white">
        <div class="container my-auto p-4">
          <div class="copyright text-center my-auto">
            <span class="text-center">Copyright &copy; <?= base_url(); ?> 2019</span>
          </div>
        </div>
      </footer><script src="<?= base_url() ?>Data-Template/js/jquery-3.2.1.min.js"></script>
    <script src="<?= base_url() ?>Data-Template/js/popper.min.js"></script>
    <script src="<?= base_url() ?>Data-Template/js/bootstrap.min.js"></script>
    <script src="<?= base_url() ?>Data-Template/js/main.js"></script>
  </body>
</html>